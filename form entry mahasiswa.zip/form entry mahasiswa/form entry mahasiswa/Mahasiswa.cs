﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace form_entry_mahasiswa
{
    public class Mahasiswa
    {
        
        public string Nim { get; set; }
        public string Name { get; set; }
        public string Alamat { get; set; }
        public string Date { get; set; }
        public string Gender { get; set; }
        public string Born { get; set; }
    }
}
